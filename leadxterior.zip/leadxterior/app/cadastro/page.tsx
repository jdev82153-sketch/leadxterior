import Link from "next/link";
import AuthShell from "@/components/auth/AuthShell";
import AuthForm from "@/components/auth/AuthForm";

export default function CadastroPage() {
  return (
    <AuthShell
      title="Crie sua conta"
      subtitle="Comece com 10 créditos grátis."
      footer={<>Já possui uma conta? <Link href="/login" className="font-semibold text-brand hover:underline">Entrar</Link></>}
    >
      <AuthForm
        submitLabel="Criar conta"
        fields={[
          { name: "nome", label: "Nome", type: "text", autoComplete: "name" },
          { name: "email", label: "E-mail", type: "email", autoComplete: "email" },
          { name: "senha", label: "Senha", type: "password", autoComplete: "new-password" },
          { name: "confirmar", label: "Confirmar senha", type: "password", autoComplete: "new-password" },
        ]}
      />
    </AuthShell>
  );
}
