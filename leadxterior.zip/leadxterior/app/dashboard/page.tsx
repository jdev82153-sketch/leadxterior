import { Bookmark, Coins, Copy, Users } from "lucide-react";
import StatCard from "@/components/dashboard/StatCard";
import LeadSearchForm from "@/components/dashboard/LeadSearchForm";

export default function DashboardPage() {
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold tracking-tight sm:text-3xl">Olá, João 👋</h1>

      <div className="flex items-center gap-4 rounded-xl border border-brand/40 bg-brand/10 p-5">
        <span className="inline-flex size-11 items-center justify-center rounded-lg bg-brand text-white"><Coins size={22} aria-hidden="true" /></span>
        <div>
          <p className="text-xl font-bold">10 créditos disponíveis</p>
          <p className="text-sm text-white/60">Plano Grátis</p>
        </div>
      </div>

      <div className="grid gap-4 sm:grid-cols-3">
        <StatCard label="Leads encontrados" value={0} icon={Users} />
        <StatCard label="Leads salvos" value={0} icon={Bookmark} />
        <StatCard label="Abordagens copiadas" value={0} icon={Copy} />
      </div>

      <LeadSearchForm />

      <div className="rounded-xl border border-dashed border-white/15 p-8 text-center">
        <p className="font-semibold">Nenhuma busca realizada</p>
        <p className="mt-1 text-sm text-white/60">Escolha um segmento e uma localização para encontrar seus primeiros leads.</p>
      </div>
    </div>
  );
}
