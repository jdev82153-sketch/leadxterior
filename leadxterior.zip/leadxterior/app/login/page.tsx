import Link from "next/link";
import AuthShell from "@/components/auth/AuthShell";
import AuthForm from "@/components/auth/AuthForm";

export default function LoginPage() {
  return (
    <AuthShell
      title="Entrar"
      subtitle="Acesse seu painel de prospecção."
      footer={<>Não possui uma conta? <Link href="/cadastro" className="font-semibold text-brand hover:underline">Criar conta</Link></>}
    >
      <AuthForm
        submitLabel="Entrar"
        fields={[
          { name: "email", label: "E-mail", type: "email", autoComplete: "email" },
          { name: "senha", label: "Senha", type: "password", autoComplete: "current-password" },
        ]}
      />
    </AuthShell>
  );
}
