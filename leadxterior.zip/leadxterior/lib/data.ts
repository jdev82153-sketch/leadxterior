import {
  Building2, SlidersHorizontal, Target, MessageSquareText, FolderKanban, History,
  LayoutDashboard, Search, Bookmark, Settings, type LucideIcon,
} from "lucide-react";
import type { Lead } from "./types";

export const navLinks = [
  { label: "Como funciona", href: "/#como-funciona" },
  { label: "Recursos", href: "/#recursos" },
  { label: "Planos", href: "/#planos" },
];

export const steps = [
  { title: "Encontre empresas", text: "Escolha um segmento e uma região para ver negócios que combinam com o seu serviço." },
  { title: "Identifique oportunidades", text: "Veja quem tem Instagram, WhatsApp ou ainda não tem site e priorize os melhores contatos." },
  { title: "Entre em contato", text: "Use uma abordagem pronta, ajuste ao seu estilo e fale com a empresa." },
];

export const features: { title: string; text: string; icon: LucideIcon }[] = [
  { title: "Busca de empresas", text: "Pesquise por segmento, cidade e país.", icon: Building2 },
  { title: "Filtros avançados", text: "Refine por presença digital e perfil do negócio.", icon: SlidersHorizontal },
  { title: "Identificação de oportunidades", text: "Destaque empresas sem site ou com canais de contato ativos.", icon: Target },
  { title: "Abordagens personalizadas", text: "Mensagens de primeiro contato adaptadas a cada lead.", icon: MessageSquareText },
  { title: "Organização de leads", text: "Salve e agrupe os contatos que valem o seu tempo.", icon: FolderKanban },
  { title: "Histórico de prospecção", text: "Acompanhe quem você já abordou e quando.", icon: History },
];

export const demoLeads: Lead[] = [
  { id: "d1", name: "Brother Burger", segment: "Hamburgueria", city: "Jales - SP", instagram: "@exemplo.brotherburger", whatsapp: "(00) 00000-0000" },
  { id: "d2", name: "Studio Aurora", segment: "Salão de beleza", city: "Votuporanga - SP", instagram: "@exemplo.aurora" },
  { id: "d3", name: "Oficina Central", segment: "Mecânica", city: "Fernandópolis - SP", whatsapp: "(00) 00000-0000" },
];

export const plans = [
  { name: "Grátis", price: "R$ 0", items: ["10 créditos", "Busca no Brasil", "Organização de leads", "Abordagens básicas"], cta: "Começar grátis", href: "/cadastro", highlight: false },
  { name: "Pro", price: "Em breve", items: ["Mais créditos", "Mais filtros", "Busca internacional", "Abordagens personalizadas", "Histórico completo"], cta: "Em breve", href: undefined, highlight: true },
];

export const dashboardNav: { label: string; href: string; icon: LucideIcon; ready: boolean }[] = [
  { label: "Dashboard", href: "/dashboard", icon: LayoutDashboard, ready: true },
  { label: "Encontrar leads", href: "#", icon: Search, ready: false },
  { label: "Minhas leads", href: "#", icon: Bookmark, ready: false },
  { label: "Abordagens", href: "#", icon: MessageSquareText, ready: false },
  { label: "Histórico", href: "#", icon: History, ready: false },
  { label: "Configurações", href: "#", icon: Settings, ready: false },
];

export const segments = ["Restaurantes", "Hamburguerias", "Salões de beleza", "Mecânicas", "Clínicas", "Academias"];
export const locations = ["Brasil", "Internacional (Pro)"];
