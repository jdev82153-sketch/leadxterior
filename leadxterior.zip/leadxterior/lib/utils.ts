export function cn(...classes: (string | false | null | undefined)[]) {
  return classes.filter(Boolean).join(" ");
}

export const inputClass =
  "h-11 w-full rounded-lg border border-white/10 bg-ink px-3 text-sm text-white placeholder:text-white/40 focus:border-brand";
