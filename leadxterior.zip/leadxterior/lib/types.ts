export type Lead = {
  id: string;
  name: string;
  segment: string;
  city: string;
  instagram?: string;
  whatsapp?: string;
  website?: string;
};
