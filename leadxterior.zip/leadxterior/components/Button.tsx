import Link from "next/link";
import { cn } from "@/lib/utils";

type Props = React.ButtonHTMLAttributes<HTMLButtonElement> & {
  href?: string;
  variant?: "primary" | "secondary" | "ghost";
  size?: "md" | "lg";
};

const variants = {
  primary: "bg-brand text-white hover:bg-blue-500",
  secondary: "border border-white/15 text-white hover:bg-white/5",
  ghost: "text-white/70 hover:text-white",
};
const sizes = { md: "h-10 px-4 text-sm", lg: "h-12 px-6 text-base" };

export default function Button({ href, variant = "primary", size = "md", className, children, ...rest }: Props) {
  const classes = cn(
    "inline-flex items-center justify-center gap-2 rounded-lg font-semibold transition-colors disabled:cursor-not-allowed disabled:opacity-50",
    variants[variant], sizes[size], className,
  );
  if (href) return <Link href={href} className={classes}>{children}</Link>;
  return <button className={classes} {...rest}>{children}</button>;
}
