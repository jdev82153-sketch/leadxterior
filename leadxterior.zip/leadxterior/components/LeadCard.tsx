import { Check, Globe, Instagram, MapPin, MessageCircle, Target } from "lucide-react";
import Button from "./Button";
import type { Lead } from "@/lib/types";

export default function LeadCard({ lead, demo = false }: { lead: Lead; demo?: boolean }) {
  const channels = [
    { icon: Instagram, label: "Instagram", value: lead.instagram },
    { icon: MessageCircle, label: "WhatsApp", value: lead.whatsapp },
    { icon: Globe, label: "Site", value: lead.website },
  ];
  const chips: { text: string; positive: boolean }[] = [];
  if (lead.instagram) chips.push({ text: "Instagram disponível", positive: true });
  if (lead.whatsapp) chips.push({ text: "WhatsApp disponível", positive: true });
  if (!lead.website) chips.push({ text: "Sem site", positive: false });

  return (
    <article className="flex flex-col rounded-xl border border-white/10 bg-ink p-5">
      <div className="flex items-start justify-between gap-3">
        <div>
          <h3 className="font-bold">{lead.name}</h3>
          <p className="text-sm text-white/60">{lead.segment}</p>
        </div>
        {demo && <span className="rounded-md bg-white/10 px-2 py-0.5 text-xs text-white/70">Exemplo</span>}
      </div>
      <p className="mt-2 flex items-center gap-1.5 text-sm text-white/60"><MapPin size={14} />{lead.city}</p>
      <dl className="mt-4 space-y-2 text-sm">
        {channels.map(({ icon: Icon, label, value }) => (
          <div key={label} className="flex items-center gap-2">
            <Icon size={15} className="text-white/40" aria-hidden="true" />
            <dt className="sr-only">{label}</dt>
            <dd className={value ? "text-white/85" : "text-white/35"}>{value ?? "Não encontrado"}</dd>
          </div>
        ))}
      </dl>
      <ul className="mt-4 flex flex-wrap gap-2">
        {chips.map((c) => (
          <li key={c.text} className={c.positive
            ? "inline-flex items-center gap-1 rounded-full bg-positive/10 px-2.5 py-1 text-xs text-positive"
            : "inline-flex items-center gap-1 rounded-full bg-iris/15 px-2.5 py-1 text-xs text-indigo-300"}>
            {c.positive ? <Check size={12} /> : <Target size={12} />}{c.text}
          </li>
        ))}
      </ul>
      <Button variant="secondary" className="mt-5 w-full">Ver lead</Button>
    </article>
  );
}
