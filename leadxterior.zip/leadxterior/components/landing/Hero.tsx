import Button from "../Button";

export default function Hero() {
  return (
    <section className="mx-auto max-w-6xl px-5 py-20 md:py-32">
      <h1 className="max-w-3xl text-4xl font-extrabold tracking-tight sm:text-5xl md:text-6xl">
        Encontre seus próximos clientes.
      </h1>
      <p className="mt-6 max-w-xl text-lg text-white/65">
        Descubra empresas, encontre oportunidades e crie abordagens personalizadas em poucos cliques.
      </p>
      <div className="mt-10 flex flex-col gap-3 sm:flex-row">
        <Button href="/cadastro" size="lg">Começar gratuitamente</Button>
        <Button href="#como-funciona" size="lg" variant="secondary">Ver como funciona</Button>
      </div>
    </section>
  );
}
