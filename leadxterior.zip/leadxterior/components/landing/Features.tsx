import { features } from "@/lib/data";

export default function Features() {
  return (
    <section id="recursos" className="mx-auto max-w-6xl px-5 py-16 md:py-24">
      <h2 className="text-3xl font-bold tracking-tight">Recursos</h2>
      <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {features.map(({ title, text, icon: Icon }) => (
          <div key={title} className="rounded-xl border border-white/10 bg-surface p-6">
            <span className="inline-flex size-10 items-center justify-center rounded-lg bg-iris/15 text-indigo-300">
              <Icon size={20} aria-hidden="true" />
            </span>
            <h3 className="mt-4 font-bold">{title}</h3>
            <p className="mt-1 text-sm text-white/60">{text}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
