import Button from "../Button";

export default function FinalCta() {
  return (
    <section className="mx-auto max-w-6xl px-5 py-16 md:py-24">
      <div className="rounded-2xl bg-iris/15 px-6 py-14 text-center sm:px-12">
        <h2 className="mx-auto max-w-xl text-3xl font-bold tracking-tight">Pronto para encontrar seus próximos clientes?</h2>
        <Button href="/cadastro" size="lg" className="mt-8">Começar gratuitamente</Button>
      </div>
    </section>
  );
}
