import { Check } from "lucide-react";
import Button from "../Button";
import { plans } from "@/lib/data";
import { cn } from "@/lib/utils";

export default function Plans() {
  return (
    <section id="planos" className="mx-auto max-w-6xl px-5 py-16 md:py-24">
      <h2 className="text-3xl font-bold tracking-tight">Planos</h2>
      <div className="mt-10 grid max-w-3xl gap-4 md:grid-cols-2">
        {plans.map((p) => (
          <div key={p.name} className={cn("flex flex-col rounded-xl border bg-surface p-6", p.highlight ? "border-brand" : "border-white/10")}>
            <h3 className="text-xl font-bold">{p.name}</h3>
            <p className="mt-1 text-2xl font-extrabold">{p.price}</p>
            <ul className="mt-6 flex-1 space-y-3 text-sm text-white/75">
              {p.items.map((i) => (
                <li key={i} className="flex items-center gap-2"><Check size={16} className="text-brand" aria-hidden="true" />{i}</li>
              ))}
            </ul>
            {p.href
              ? <Button href={p.href} className="mt-8 w-full">{p.cta}</Button>
              : <Button disabled variant="secondary" className="mt-8 w-full">{p.cta}</Button>}
          </div>
        ))}
      </div>
    </section>
  );
}
