import { steps } from "@/lib/data";

export default function HowItWorks() {
  return (
    <section id="como-funciona" className="mx-auto max-w-6xl px-5 py-16 md:py-24">
      <h2 className="text-3xl font-bold tracking-tight">Como funciona</h2>
      <ol className="mt-10 grid gap-8 md:grid-cols-3">
        {steps.map((s, i) => (
          <li key={s.title} className="border-t border-white/15 pt-5">
            <span className="text-sm font-semibold text-brand">Etapa {i + 1}</span>
            <h3 className="mt-2 text-xl font-bold">{s.title}</h3>
            <p className="mt-2 max-w-sm text-white/60">{s.text}</p>
          </li>
        ))}
      </ol>
    </section>
  );
}
