import Link from "next/link";
import Logo from "../Logo";
import { navLinks } from "@/lib/data";

export default function Footer() {
  const links = [...navLinks, { label: "Entrar", href: "/login" }, { label: "Criar conta", href: "/cadastro" }];
  return (
    <footer className="border-t border-white/10">
      <div className="mx-auto flex max-w-6xl flex-col gap-6 px-5 py-10 md:flex-row md:items-center md:justify-between">
        <Logo />
        <nav className="flex flex-wrap gap-x-6 gap-y-2 text-sm text-white/60" aria-label="Rodapé">
          {links.map((l) => <Link key={l.href} href={l.href} className="hover:text-white">{l.label}</Link>)}
        </nav>
        <p className="text-sm text-white/40">© 2026 LeadXterior</p>
      </div>
    </footer>
  );
}
