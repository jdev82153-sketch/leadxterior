import { Info } from "lucide-react";
import LeadCard from "../LeadCard";
import { demoLeads } from "@/lib/data";

export default function Demo() {
  return (
    <section id="demonstracao" className="mx-auto max-w-6xl px-5 py-16 md:py-24">
      <h2 className="text-3xl font-bold tracking-tight">Veja como ficam seus leads</h2>
      <p className="mt-3 max-w-xl text-white/60">Cada empresa aparece com os canais de contato e as oportunidades já destacados.</p>
      <div className="mt-10 rounded-2xl border border-dashed border-brand/50 bg-surface p-4 sm:p-6">
        <div className="mb-5 flex flex-wrap items-center gap-3 rounded-lg bg-brand/10 px-3 py-2 text-sm text-blue-200">
          <Info size={16} aria-hidden="true" />
          <span><strong>Demonstração.</strong> Empresas e dados fictícios, criados só para ilustrar o painel. Nada aqui foi pesquisado.</span>
        </div>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {demoLeads.map((l) => <LeadCard key={l.id} lead={l} demo />)}
        </div>
      </div>
    </section>
  );
}
