import Link from "next/link";
import { cn } from "@/lib/utils";

// Marca provisória em SVG. Quando adicionar public/logo.png, troque o <svg> por <Image src="/logo.png" ... />.
export default function Logo({ className }: { className?: string }) {
  return (
    <Link href="/" className={cn("inline-flex items-center gap-2 font-bold tracking-tight", className)} aria-label="LeadXterior">
      <svg width="28" height="28" viewBox="0 0 28 28" aria-hidden="true">
        <rect width="28" height="28" rx="7" fill="#3B82F6" />
        <path d="M9 9l10 10M19 9L9 19" stroke="#fff" strokeWidth="2.6" strokeLinecap="round" />
      </svg>
      <span className="text-lg">LeadXterior</span>
    </Link>
  );
}
