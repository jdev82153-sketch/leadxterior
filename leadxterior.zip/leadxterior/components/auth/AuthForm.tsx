"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import Button from "../Button";
import { inputClass } from "@/lib/utils";

export type AuthField = { name: string; label: string; type: string; autoComplete?: string };

// Sem autenticação real: ao enviar, apenas navega para o dashboard de demonstração.
export default function AuthForm({ fields, submitLabel }: { fields: AuthField[]; submitLabel: string }) {
  const router = useRouter();
  const [error, setError] = useState("");

  function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const data = new FormData(e.currentTarget);
    if (data.has("confirmar") && data.get("senha") !== data.get("confirmar")) {
      setError("As senhas não coincidem. Digite a mesma senha nos dois campos.");
      return;
    }
    router.push("/dashboard");
  }

  return (
    <form onSubmit={onSubmit} className="space-y-4">
      {fields.map((f) => (
        <div key={f.name}>
          <label htmlFor={f.name} className="mb-1.5 block text-sm font-medium text-white/80">{f.label}</label>
          <input id={f.name} name={f.name} type={f.type} autoComplete={f.autoComplete} required className={inputClass} />
        </div>
      ))}
      {error && <p role="alert" className="text-sm text-red-400">{error}</p>}
      <Button type="submit" size="lg" className="w-full">{submitLabel}</Button>
    </form>
  );
}
