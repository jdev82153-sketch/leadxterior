"use client";

import Link from "next/link";
import { useState } from "react";
import { Menu, X } from "lucide-react";
import Logo from "./Logo";
import Button from "./Button";
import { navLinks } from "@/lib/data";

export default function Navbar() {
  const [open, setOpen] = useState(false);
  return (
    <header className="sticky top-0 z-40 border-b border-white/10 bg-ink/90 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-5">
        <Logo />
        <nav className="hidden items-center gap-8 md:flex" aria-label="Principal">
          {navLinks.map((l) => (
            <Link key={l.href} href={l.href} className="text-sm text-white/70 hover:text-white">{l.label}</Link>
          ))}
        </nav>
        <div className="hidden items-center gap-2 md:flex">
          <Button href="/login" variant="ghost">Entrar</Button>
          <Button href="/cadastro">Começar grátis</Button>
        </div>
        <button className="p-2 md:hidden" onClick={() => setOpen(!open)} aria-expanded={open} aria-label={open ? "Fechar menu" : "Abrir menu"}>
          {open ? <X size={22} /> : <Menu size={22} />}
        </button>
      </div>
      {open && (
        <div className="border-t border-white/10 px-5 pb-5 md:hidden">
          <nav className="flex flex-col py-2" aria-label="Mobile">
            {navLinks.map((l) => (
              <Link key={l.href} href={l.href} onClick={() => setOpen(false)} className="py-3 text-white/80">{l.label}</Link>
            ))}
            <Link href="/login" className="py-3 text-white/80">Entrar</Link>
          </nav>
          <Button href="/cadastro" className="w-full">Começar grátis</Button>
        </div>
      )}
    </header>
  );
}
