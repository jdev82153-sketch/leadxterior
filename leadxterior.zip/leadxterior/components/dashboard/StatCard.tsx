import type { LucideIcon } from "lucide-react";

export default function StatCard({ label, value, icon: Icon }: { label: string; value: number; icon: LucideIcon }) {
  return (
    <div className="rounded-xl border border-white/10 bg-surface p-5">
      <div className="flex items-center justify-between text-white/60">
        <span className="text-sm">{label}</span>
        <Icon size={18} aria-hidden="true" />
      </div>
      <p className="mt-3 text-3xl font-extrabold">{value}</p>
    </div>
  );
}
