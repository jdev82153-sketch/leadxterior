"use client";

import { useState } from "react";
import { Search } from "lucide-react";
import Button from "../Button";
import { inputClass } from "@/lib/utils";
import { locations, segments } from "@/lib/data";

export default function LeadSearchForm() {
  const [submitted, setSubmitted] = useState(false);

  return (
    <form
      onSubmit={(e) => { e.preventDefault(); setSubmitted(true); }}
      className="rounded-xl border border-white/10 bg-surface p-5 sm:p-6"
    >
      <h2 className="text-lg font-bold">Encontrar novos leads</h2>
      <div className="mt-5 grid gap-4 sm:grid-cols-3">
        <div>
          <label htmlFor="segmento" className="mb-1.5 block text-sm font-medium text-white/80">Segmento</label>
          <select id="segmento" defaultValue="" className={inputClass}>
            <option value="" disabled>Escolha um segmento</option>
            {segments.map((s) => <option key={s}>{s}</option>)}
          </select>
        </div>
        <div>
          <label htmlFor="localizacao" className="mb-1.5 block text-sm font-medium text-white/80">Localização</label>
          <select id="localizacao" defaultValue="" className={inputClass}>
            <option value="" disabled>Escolha uma localização</option>
            {locations.map((l) => <option key={l}>{l}</option>)}
          </select>
        </div>
        <div>
          <label htmlFor="cidade" className="mb-1.5 block text-sm font-medium text-white/80">Cidade</label>
          <input id="cidade" placeholder="Digite uma cidade" className={inputClass} />
        </div>
      </div>
      <Button type="submit" size="lg" className="mt-5 w-full sm:w-auto"><Search size={18} />Buscar leads</Button>
      {submitted && (
        <p role="status" className="mt-4 text-sm text-white/60">A busca real ainda não está disponível. Em breve seus resultados aparecerão aqui.</p>
      )}
    </form>
  );
}
