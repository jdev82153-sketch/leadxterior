"use client";

import Link from "next/link";
import { useState } from "react";
import { LogOut, Menu, X } from "lucide-react";
import Logo from "../Logo";
import { dashboardNav } from "@/lib/data";
import { cn } from "@/lib/utils";

function NavList({ onNavigate }: { onNavigate?: () => void }) {
  return (
    <nav className="flex flex-1 flex-col gap-1" aria-label="Painel">
      {dashboardNav.map(({ label, href, icon: Icon, ready }) => (
        <Link
          key={label}
          href={href}
          onClick={onNavigate}
          aria-current={ready ? "page" : undefined}
          className={cn("flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium",
            ready ? "bg-brand/15 text-white" : "text-white/60 hover:bg-white/5 hover:text-white")}
        >
          <Icon size={18} aria-hidden="true" />{label}
        </Link>
      ))}
      <Link href="/" className="mt-auto flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm text-white/60 hover:bg-white/5 hover:text-white">
        <LogOut size={18} aria-hidden="true" />Sair
      </Link>
    </nav>
  );
}

export default function Sidebar() {
  const [open, setOpen] = useState(false);
  return (
    <>
      <aside className="fixed inset-y-0 left-0 hidden w-64 flex-col gap-6 border-r border-white/10 bg-surface p-4 lg:flex">
        <Logo className="px-2" />
        <NavList />
      </aside>

      <div className="sticky top-0 z-30 flex h-14 items-center justify-between border-b border-white/10 bg-ink/90 px-4 backdrop-blur lg:hidden">
        <Logo />
        <button onClick={() => setOpen(true)} className="p-2" aria-label="Abrir menu"><Menu size={22} /></button>
      </div>

      {open && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-black/60" onClick={() => setOpen(false)} aria-hidden="true" />
          <aside className="absolute inset-y-0 left-0 flex w-72 max-w-[85%] flex-col gap-6 bg-surface p-4">
            <div className="flex items-center justify-between px-2">
              <Logo />
              <button onClick={() => setOpen(false)} className="p-1" aria-label="Fechar menu"><X size={22} /></button>
            </div>
            <NavList onNavigate={() => setOpen(false)} />
          </aside>
        </div>
      )}
    </>
  );
}
